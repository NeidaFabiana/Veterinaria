<?php
$news = $data['noticia'];

?>

<section>
            <div class="container">		 
                <div class="row">
                    <div class="col-lg-12">

					<?php if ($news): ?>
					
						<h1 class="s-content__header-title"><?php echo $news->getTitle()?></h1>
						 <p><?php echo $news->getDescripcion()?></p>
						 
						<?php foreach ($news->getListImagens() as $imagem): ?>
						                        <img class=centerImg src="<?= $this->asset ?>system/upload/<?= $imagem->getNombre() ?>"width="200" height="150">
					
					  
					 <?php endforeach; ?>
					 
					 
                       
                        <?php else: ?>
                  <h3>Notícia não encontrada!</h3>
						<?php endif; ?>
                        <a href="<?php echo $this->base_url?>#noticias">Volver</a>
                    </div>
                </div>
            </div>
        </section>