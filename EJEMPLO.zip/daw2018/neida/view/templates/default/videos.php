

<section>
				
		<div class="container">
                <div class="row">
					 <div class="col-lg-12">
                        <h1><center>Adiestrar</center></h1>
					
</br>


    <script>
        init_jssor_slider2 = function (slider2_container) {

            var options = {
                $Loop: 0,
                $DragOrientation: 3,                        //[Optional] Orientation to drag slide, 0 no drag, 1 horizental, 2 vertical, 3 either, default value is 1 (Note that the $DragOrientation should be the same as $PlayOrientation when $Cols is greater than 1, or parking position is not 0)
                $SlideDuration: 500,                        //[Optional] Specifies default duration (swipe) for slide in milliseconds, default value is 500

                $ThumbnailNavigatorOptions: {               //[Optional] Options to specify and enable thumbnail navigator or not
                    $Class: $JssorThumbnailNavigator$,      //[Required] Class to create thumbnail navigator instance
                    $ChanceToShow: 2,                       //[Required] 0 Never, 1 Mouse Over, 2 Always

                    $ActionMode: 1,                         //[Optional] 0 None, 1 act by click, 2 act by mouse hover, 3 both, default value is 1
                    $SpacingX: 5,                           //[Optional] Horizontal space between each thumbnail in pixel, default value is 0
                    $Cols: 5,                               //[Optional] Number of pieces to display, default value is 1
                    $Align: 390                             //[Optional] The offset position to park thumbnail
                }
            };

            var jssor_slider2 = new $JssorSlider$(slider2_container, options);
        };
    </script>

    <!--#region Jssor Slider Begin -->
    
    <div id="slider2_container" style="position: relative; width: 900px; height: 480px; overflow: hidden;margin: 0 auto;width:800;">
 
       

        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:380px;overflow:hidden;">
		        <?php foreach ($data['listVideo'] as $listaVideo): ?>

          <div>
              <iframe data-u="image" width="980" height="380" src="https://www.youtube.com/embed/<?php echo $listaVideo->getLiink() ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
              <img data-u="thumb" src="https://www.youtube.com/embed/<?php echo $listaVideo->getThumb()?>" />
          </div>

        <?php endforeach; ?>

        <!--#region Thumbnail Navigator Skin Begin -->
        <!-- Help: https://www.jssor.com/development/slider-with-thumbnail-navigator.html -->
        <style>
            .jssort062 .p {position:absolute;top:0;left:0;border:2px solid rgba(0,0,0,.4);box-sizing:border-box;}
            .jssort062 .t {position:absolute;top:0;left:0;width:100%;height:100%;border:none;opacity:.6;}
            .jssort062 .p:hover {border-color:rgba(255,255,255,.6);}
            .jssort062 .pav, .jssort062 .p:hover.pdn{border-color:#fff;}
            .jssort062 .pav .t, .jssort062 .p:hover.pdn .t{opacity:1;}
        </style>
        <div data-u="thumbnavigator" class="jssort062" style="position:absolute;left:0px;bottom:0px;width:980px;height:100px;background-color:#000;" data-autocenter="1" data-scale-bottom="0.75">
            <div data-u="slides">
                <div data-u="prototype" class="p" style="width:190px;height:84px;">
                    <div data-u="thumbnailtemplate" class="t"></div>
                </div>
            </div>
        </div>
        <!--#endregion Thumbnail Navigator Skin End -->

        <!-- Trigger -->
        <script>
            init_jssor_slider2("slider2_container");
        </script>
    </div>
 
</div>


			</div>	
		</div>	
	</div>
 </section>
		


