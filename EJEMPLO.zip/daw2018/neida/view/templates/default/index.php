<?php
$list_news = $data['listNews'];
$list_imagem = $data['listImagem'];
$list_video = $data['listVideo'];
?>

    <!-- Header -->
    <header class="masthead">
      <div class="container">
        <div class="intro-text">
          <div class="intro-lead-in">¡Bienvenidos al Mundo de Perros!</div>
          <div class="intro-heading text-uppercase"></div>
         
        </div>
      </div>
    </header>

    <!-- Noticias -->
    <section id="noticias">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Notícias</h2>
            <h3 class="section-subheading text-muted"></h3>
          </div>
        </div>
        <div class="row text-center">
          
			<?php if ($list_news): ?>
				 <?php foreach ($list_news as $news): ?>
				 <div class="col-md-4">
						<?php if ($news->getListImagens()): ?>
			 <img src="<?php echo $this->asset . "system/upload/" . $news->getListImagens()[0]->getNombre(); ?>" width="230" height="160" />

		    <a href="<?php echo $this->url."News/viewNews/".$news->getIdnoticia()?>">
            <h4 class="service-heading"><?php echo $news->getTitle() ?></h4></a>
            <p class="text-muted"><?php echo $news->getDescripcion()?></p>
     

		 <?php endif; ?>
			</div>		
          <?php endforeach;?>	
		                      
					<?php else:?>
                           <li>Não foram cadastradas notícias!</li>
                    <?php endif; ?>
		  </div>
        <div class="row text-center">
		<div class="col-md-4 offset-8" >
		
		 <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="<?php echo $this->base_url?>News">Ver más</a>
		 
		 </div>
		 </div>
      </div>
    </section>
	
	  <!-- Razas -->
    <section class="bg-light" id="razas">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Razas</h2>
            <h3 class="section-subheading text-muted">De mi mascota aprendí que la lealtad si existe.</h3>
          </div>
        </div>
        <div class="row text-center">
		<?php if ($list_imagem): ?>
				 <?php foreach ($list_imagem as $img): ?>
          <div class="col-md-4">
			 <img src="<?php echo $this->asset . "system/upload/" . $img->getNombre(); ?>" width="230" height="160" />

		  <p class="text-muted"><?php echo $img->getDescripcion()?></p>
     
			</div>		
          <?php endforeach;?>	

					 <?php else:?>
                           <li>Não foram cadastradas imagens</li>
                    <?php endif; ?>
		  </div>
         <div class="row text-center">
		<div class="col-md-4 offset-8" >
		
		 <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="<?php echo $this->url?>Imagenes">Ver más</a>
		 
		 </div>
      </div>
      </div>
    </section>

	 <!-- Adiestrar -->
    <section  id="adiestrar">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Adiestrar</h2>
            <h3 class="section-subheading text-muted">Un perro tranquilo es un perro sano.</h3>
          </div>
        </div>
        <div class="row">
           
		   	<?php if ($list_video): ?>
                          <?php foreach ($list_video as $video): ?>
		 <div class="col-sm-4">
		<div>
				<iframe width="230" height="160" src="https://www.youtube.com/embed/<?php echo $video->getLiink() ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
             
              <img data-u="thumb" src="<?php echo $video->getThumb()?>" />
          </div>						
            <h5 class="service-heading"><?php echo $video->getTitulo() ?></h5>
            <p class="text-muted"><?php echo $video->getDescripcion()?></p>
     
	   </div>
         
          <?php endforeach;?>	
		                       

					 <?php else:?>
                           <li>No fueron cadastrados los videos...</li>
                    <?php endif; ?>
		  </div>
          </div>
		
        
       <div class="row text-center">
		<div class="col-md-4 offset-8" >
		
		 <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="<?php echo $this->url?>Videos">Ver más</a>
		 
		 </div>
      </div>
      </div>
    </section>



   
    

  
    <!-- Clients -->
    <section class="py-5">
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6">
            <a href="#">
              <img class="img-fluid d-block mx-auto" src="<?php echo $this->asset?>img/logos/envato.jpg" alt="">
            </a>
          </div>
          <div class="col-md-3 col-sm-6">
            <a href="#">
              <img class="img-fluid d-block mx-auto" src="<?php echo $this->asset?>img/logos/designmodo.jpg" alt="">
            </a>
          </div>
          <div class="col-md-3 col-sm-6">
            <a href="#">
              <img class="img-fluid d-block mx-auto" src="<?php echo $this->asset?>img/logos/themeforest.jpg" alt="">
            </a>
          </div>
          <div class="col-md-3 col-sm-6">
            <a href="#">
              <img class="img-fluid d-block mx-auto" src="<?php echo $this->asset?>img/logos/creative-market.jpg" alt="">
            </a>
          </div>
        </div>
      </div>
    </section>

    <!-- Contact -->
    <section id="contact">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase">Contact Us</h2>
            <h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <form id="contactForm" name="sentMessage" novalidate>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <input class="form-control" id="name" type="text" placeholder="Your Name *" required data-validation-required-message="Please enter your name.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" id="email" type="email" placeholder="Your Email *" required data-validation-required-message="Please enter your email address.">
                    <p class="help-block text-danger"></p>
                  </div>
                  <div class="form-group">
                    <input class="form-control" id="phone" type="tel" placeholder="Your Phone *" required data-validation-required-message="Please enter your phone number.">
                    <p class="help-block text-danger"></p>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <textarea class="form-control" id="message" placeholder="Your Message *" required data-validation-required-message="Please enter a message."></textarea>
                    <p class="help-block text-danger"></p>
                  </div>
                </div>
                <div class="clearfix"></div>
                <div class="col-lg-12 text-center">
                  <div id="success"></div>
                  <button id="sendMessageButton" class="btn btn-primary btn-xl text-uppercase" type="submit">Send Message</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

  
    