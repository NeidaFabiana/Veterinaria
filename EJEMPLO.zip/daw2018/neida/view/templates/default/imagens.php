<?php
$img = $data['listImagem'];
?>
 <section>

		<div class="container">
                <div class="row">
					 <div class="col-lg-12">
                        <h1><center>Razas</center></h1>

</br>

    <div id="slider1_container" style="position: relative; width: 900px; height: 500px; overflow: hidden;margin:0 auto;width:800px;">


        <div u="slides" style="position: absolute; left: 0px; top: 0px; width: 900px; height: 500px;
            overflow: hidden;">

			    <?php foreach ($img as $listaImagem): ?>

            <div data-p="170.00">
				<img data-u="image" src="<?= $this->asset?>system/upload/<?php echo $listaImagem->getNombre()?>" />            </div>
          <?php endforeach; ?>
        </div>

        <style>
            .jssora092 {display:block;position:absolute;cursor:pointer;}
            .jssora092 .c {fill:#000;fill-opacity:0.5;}
            .jssora092 .a {fill:#ddd;}
            .jssora092:hover {opacity:.8;}
            .jssora092.jssora092dn {opacity:.5;}
            .jssora092.jssora092ds {opacity:.3;pointer-events:none;}
        </style>
        <div data-u="arrowleft" class="jssora092" style="width:24px;height:40px;top:0px;left:-1px;" data-autocenter="2" data-scale="0.75" data-scale-left="0">
            <svg viewBox="-199 -3000 9600 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <path class="c" d="M-199-2428.1C317.2-2538.7,851.8-2600,1401-2600c4197.3,0,7600,3402.7,7600,7600 s-3402.7,7600-7600,7600c-549.2,0-1083.8-61.3-1600-171.9V-2428.1z"></path>
                <polygon class="a" points="4806.7,1528.5 4806.7,1528.5 4806.7,2707.8 2691.1,5000 4806.7,7292.2 4806.7,8471.5 4806.7,8471.5 1602,5000 "></polygon>
            </svg>
        </div>
        <div data-u="arrowright" class="jssora092" style="width:24px;height:40px;top:0px;right:-1px;" data-autocenter="2" data-scale="0.75" data-scale-right="0">
            <svg viewBox="-199 -3000 9600 16000" style="position:absolute;top:0;left:0;width:100%;height:100%;">
                <path class="c" d="M9401,12428.1c-516.2,110.6-1050.8,171.9-1600,171.9c-4197.3,0-7600-3402.7-7600-7600 s3402.7-7600,7600-7600c549.2,0,1083.8,61.3,1600,171.9V12428.1z"></path>
                <polygon class="a" points="7401,5000 4196.3,8471.5 4196.3,8471.5 4196.3,7292.2 6311.9,5000 4196.3,2707.8 4196.3,1528.5 4196.3,1528.5 "></polygon>
            </svg>
        </div>


        <script>
        init_jssor_slider1 = function (slider1_container) {

            var options = {
                $Loop: 0,
                $DragOrientation: 3,                        //[Optional] Orientation to drag slide, 0 no drag, 1 horizental, 2 vertical, 3 either, default value is 1 (Note that the $DragOrientation should be the same as $PlayOrientation when $Cols is greater than 1, or parking position is not 0)
                $SlideDuration: 500,                        //[Optional] Specifies default duration (swipe) for slide in milliseconds, default value is 500

                $ArrowNavigatorOptions: {                   //[Optional] Options to specify and enable arrow navigator or not
                    $Class: $JssorArrowNavigator$,          //[Requried] Class to create arrow navigator instance
                    $ChanceToShow: 2,                       //[Required] 0 Never, 1 Mouse Over, 2 Always
                    $AutoCenter: 2,                         //[Optional] Auto center arrows in parent container, 0 No, 1 Horizontal, 2 Vertical, 3 Both, default value is 0
                    $Steps: 1                               //[Optional] Steps to go for each navigation request, default value is 1
                }
            };

            var jssor_slider1 = new $JssorSlider$(slider1_container, options);
        };
    </script>
    <script>
            init_jssor_slider1("slider1_container");
        </script>
    </div>


</div>
</div>
				</div>
		</div>
 </section>


