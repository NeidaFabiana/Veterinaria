<?php
$list_news = $data['listNews'];
?>
        <section>
            <div class="container">
                <div class="row">
					 <div class="col-lg-12">
                        <h1><center>Notícias</center></h1>
						</br>
						  <ul> 
								
		<div id="primary" class="row primary">

      <?php if ($list_news): ?>
	  
	  <?php foreach($list_news as $news):?>
						
              <div class="col-sm-3">
			  
			  <?php foreach ($news->getListImagens() as $imagem): ?>
                  <img class="rounded-circle" width="150" height="150" src="<?php echo $this->asset."system/upload/".$imagem->getNombre()?>" alt="">
               <?php endforeach;?>			
			</div>
              <div class="col-sm-9">	                   
							<a href="<?php echo $this->base_url?>News/viewNews/<?php echo $news->getIdnoticia()?>">
							<?php echo $news->getTitle()?> </a>						
							<p><?php echo $news->getDescripcion()?></p>							
                  <a class="enlace-pink" href="<?php echo $this->base_url?>News/viewNews/<?php echo $news->getIdnoticia()?>" role="button">Leer más »</a>			  
              </div>		                      
					<?php endforeach;?>
					 <?php else:?>
                           <li>Não foram cadastradas notícias!</li>
                    <?php endif; ?>
                        </ul>
					</div>
                </div>
            </div>
        </section>
		
		
		
	