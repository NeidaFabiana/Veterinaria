<?php

    $message = $data['msg'];
    $usuario = $data['usuario'];


?>
 <div style="margin:80px auto">

<main class="app-content">

  <div class="row">
</br>
</br>
    <div class="clearix"></div>
    <div class="col-md-12">
      <div class="tile">
        <h3 class="tile-title">Editar Usuario</h3>
        <div class="tile-body">
		              

          <form class="row" method="post" enctype="multipart/form-data">
             
			 
			 
			 <div class="form-group col-md-3">
              <label class="control-label">Nombre:</label>
              <input class="form-control" name="nome" placeholder="nombre"  value = "<?php echo $usuario->getNome();?>">
            </div>
			
			<div class="form-group col-md-3">
              <label class="control-label">Login:</label>
              <input class="form-control" name="login" placeholder="login"  value = "<?php echo $usuario->getLogin();?>">
            </div>
			
			<div class="form-group col-md-3">
              <label class="control-label">Seña:</label>
              <input class="form-control" name="senha" placeholder="senha"  value = "<?php echo $usuario->getSenha();?>">
            </div>
			
			<div class="form-group col-md-3">
              <label class="control-label">Email:</label>
              <input class="form-control" name="email" placeholder="email"  value = "<?php echo $usuario->getEmail();?>">
            </div>

            <div class="form-group">
                <input name="upd" type="submit" class="btn btn-primary" value="Salvar">
                <input name="exit" type="submit" class="btn btn-danger" value="Cancelar">
            </div>
		  
		  </form>
		                          <?php if ($message): ?>
                            <div class="form-group">
                                <div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <?php echo $message; ?>
                                </div>
                            </div>
                        <?php endif; ?>
		  
        </div>
      </div>
    </div>

  </div>
</main>
 </div>