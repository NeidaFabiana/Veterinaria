<?php
$message = "Notícia não encontrada !!";
if ($data) {
    $message = $data['msg'];
}
if($data['usuario']){
    $usuario = $data['usuario'];
}else{
    $message = "Notícia não encontrada !!";
}


?>
  <div style="margin:80px auto">

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Administrar Usuario</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="panel panel-default">
            <div class="panel-heading">
                Eliminar Usuario
            </div>
            <div class="panel-body">

                <div class="row">
                    <div class="col-lg-6">
                            <div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                  Deseas eliminar?
                                </div>
                        <form role="form"  method="post">

								
								<div class="form-group">
                                    <label>Nombre:</label>
                                    <p ><?php echo $usuario->getNome();?></p>
                                </div>
								
                                <div class="form-group">
                                    <label>Login:</label>
                                    <p ><?php echo $usuario->getLogin();?></p>
                                </div>
								
								<div class="form-group">
                                    <label>Seña:</label>
                                    <p ><?php echo $usuario->getSenha();?></p>
                                </div>
								
								<div class="form-group">
                                    <label>Email:</label>
                                    <p ><?php echo $usuario->getEmail();?></p>
                                </div>
								
								
                                <input type="hidden" value="<?php echo $usuario->getId_user() ?>" name="id_user">
                                <div class="form-group">
                                    <input name="del" type="submit" class="btn btn-danger" value="Deletar">
                                    <input name="exit" type="submit" class="btn btn-secondary" value="Cancelar">
                                </div>
                            </form> 
                        <?php if ($message): ?>
                            <div class="form-group">
                                <div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <?php echo $message; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /.row -->

</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->