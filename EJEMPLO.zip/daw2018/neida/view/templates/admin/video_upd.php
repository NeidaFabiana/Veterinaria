<?php
$vide = null;
$message = "Video no encontrado !!";
if ($data) {
    $message = $data['msg'];
    if (isset($data['vide'])) {
        $vide = $data['vide'];
    }
}
?>
 <div style="margin:80px auto">

<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i> Video</h1>
          <p>Editar Video</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Videos</li>
          <li class="breadcrumb-item"><a href="#">Editar</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-8 mx-auto">
          <div class="tile">
            <div class="tile-body">
			     <?php if ($vide): ?>
              <form role="form"  method="post">
                <div class="form-group">
                  <label class="control-label">Titulo del video</label>
                  <input class="form-control" placeholder="Titulo" name="titulo"  value = "<?php echo $vide->getTitulo();?>">
                </div>

				<div class="form-group">
                    <label class="control-label">Descripcion del Video</label>
                    <textarea name="descripcion" class="form-control" rows="4" placeholder="Descripción" ><?php echo $vide->getDescripcion();?></textarea>
                </div>
				
                <div class="form-group">
                    <label class="control-label">Link del Video</label>
                  <input class="form-control" placeholder="Link" name="liink" value = "<?php echo $vide->getLiink();?>">
                </div>

				 <div class="form-group">
                    <label class="control-label">Thumb del Video</label>
                  <input class="form-control" placeholder="Thumb" name="thumb" value = "<?php echo $vide->getThumb();?>">
                </div>

                <input type="hidden" value="<?php echo $vide->getIdvideos() ?>" name="idvideos">
                                <div class="tile-footer">
                                    <input name="edit" type="submit" class="btn btn-primary" value="Salvar">
                                    <input name="exit" type="submit" class="btn btn-danger" value="Cancelar">
                                </div>
                            </form>
                        <?php endif; ?>

						
                        <?php if ($message): ?>
                            <div class="form-group">
                                <div class="alert alert-danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <?php echo $message; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /.row -->

</div>
<!-- /#page-wrapper -->

<!-- /#wrapper -->