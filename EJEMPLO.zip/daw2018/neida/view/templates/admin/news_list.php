<?php
if($data){
    $list_news = $data['listNews'];
}else{
    $list_news = null;
}

?>
  <div style="margin:80px auto">

<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Noticias</h1>
          <p></p>


        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Noticias</li>
          <li class="breadcrumb-item active">Lista</li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
          <a style="margin-top:-40px; margin-bottom:20px;" class="btn btn-success" href="<?php echo $this->base_url?>AdminNews/add"><i class="fa fa-plus" aria-hidden="true"></i>Adicionar</a>

            <div class="tile-body" height="100" width="100">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>titulo</th>
                    <th>Descripción</th>
                    <th>Acciónes</th>
                  </tr>
                </thead>
                <tbody>
				<?php $count = 0;?>
                         <?php if($list_news):?>   
                           <?php foreach($list_news as $listNews): ?> 
                            <?php $count++; $ccs_class=($count%2==0)?'even':'odd';?>  
						<tr class="<?php echo $ccs_class;?>">
                        <td><?php echo $listNews->getIdnoticia() ?></td>
                        <td><?php echo $listNews->getTitle() ?></td>
						<td><?php echo substr($listNews->getDescripcion(), 0,50)."...";?></td>                        
                         <td class="center" style='font-size:10px; font-weight: bold;'>
                                        <a href="<?php echo $this->base_url?>AdminNews/editNews/<?php echo $listNews->getIdnoticia();?>"><i class="fa fa-edit fa-2x"></i></a>
                          
                                        <a href='<?php echo $this->base_url?>AdminNews/delNews/<?php echo $listNews->getIdnoticia();?>'>&#128465;</a>
                                    </td>
                        </tr>
                <?php endforeach; ?>
                          <?php endif;?>   
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>
 </div>