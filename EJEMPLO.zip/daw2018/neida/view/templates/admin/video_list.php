<?php
if($data){
    $list_video = $data['listVideo'];
}else{
    $list_video = null;
}

?>
 <div style="margin:80px auto">

<main class="app-content">
      <div class="app-Name">
        <div>
          <h1><i class="fa fa-th-list"></i> Videos</h1>


        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Video</li>
          <li class="breadcrumb-item active"><a href="#">Lista</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-13">
          <div class="tile">
          <a style="margin-top:-40px; margin-bottom:20px;" class="btn btn-success" href="<?php echo $this->base_url?>AdminVideo/add"><i class="fa fa-plus" aria-hidden="true"></i>Adicionar</a>

            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Id:</th>
                    <th>Titulo:</th>
                    <th>Descripcion: </th>
					<th>Link:</th>
                    <th>Thumb:</th>
					<th>Acciones:</th>
                  </tr>
                </thead>
                <tbody>
                 <?php $count = 0;?>
                         <?php if($list_video):?>   
                           <?php foreach($list_video as $listaVideo): ?> 
                            <?php $count++; $ccs_class=($count%2==0)?'even':'odd';?>  
						<tr class="<?php echo $ccs_class;?>">
                        <td><?php echo $listaVideo->getIdvideos() ?></td>
                        <td><?php echo $listaVideo->getTitulo() ?></td>
						<td><?php echo substr($listaVideo->getDescripcion(), 0,50)."...";?></td>                      
                        <td><?php echo $listaVideo->getLiink() ?></td>
						<td><?php echo $listaVideo->getThumb() ?></td>
                        <td class="center" style='font-size:10px; font-weight: bold;'>
                            <a href="<?php echo $this->base_url?>AdminVideo/editVideo/<?php echo $listaVideo->getIdvideos();?>"><i class="fa fa-edit fa-2x"></i></a>
                     
                                        <a href='<?php echo $this->base_url?>AdminVideo/delVideo/<?php echo $listaVideo->getIdvideos();?>'>&#128465;</a>
                                    </td>
                        </tr>
			
                <?php endforeach; ?>
				
						<?php endif;?>  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>
 </div>