<!-- MAIN CONTENT-->
 <div style="margin:80px auto">
       <main class="app-content">
 <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i>Mundo de perros</h1>


        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Home</li>
        </ul>
      </div>            
		</main>

   </div>           
                      
                      <!-- END MAIN CONTENT-->
                      <!-- END PAGE CONTAINER-->
                  