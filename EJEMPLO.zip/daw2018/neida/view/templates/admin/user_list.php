
 <div style="margin:80px auto">

<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i> Usuario</h1>
          <p></p>


        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Usuario</li>
          <li class="breadcrumb-item active"><a href="#">Lista</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
          <a style="margin-top:-40px; margin-bottom:20px;" class="btn btn-success" href="<?php echo $this->base_url?>AdminUsuario/add"><i class="fa fa-plus" aria-hidden="true"></i>Adicionar</a>

            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Id:</th>
                    <th>Nombre:</th>
                    <th>Login:</th>
                    <th>Seña:</th>
					<th>Email:</th>
                    <th>Acciones:</th>

                  </tr>
                </thead>
                <tbody>
                    <?php foreach ($data['listUsuario'] as $listUsuario): ?>
						<tr class="<?php echo $ccs_class;?>">
                        <td><?php echo $listUsuario->getId_user() ?></td>
						
                        <td><?php echo $listUsuario->getNome() ?></td>
                        <td><?php echo $listUsuario->getLogin()?></td>      
						<td><?php echo $listUsuario->getSenha()?></td> 
						<td><?php echo $listUsuario->getEmail()?></td> 

                        <td class="center" style='font-size:10px; font-weight: bold;'>
                           <a href="<?php echo $this->url?>AdminUsuario/editUsuario/<?php echo $listUsuario->getId_user();?>"><i class="fa fa-edit fa-2x"></i></a>
                      
                           <a href="<?php echo $this->url?>AdminUsuario/removeUsuario/<?php echo $listUsuario->getId_user();?>">&#128465;</a>
                        </td>
                        </tr>
			<?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>

	</div>
	                              