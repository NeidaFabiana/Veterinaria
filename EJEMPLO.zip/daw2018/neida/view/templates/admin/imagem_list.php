<?php
if($data){
    $list_img = $data['listImagem'];
}else{
    $list_img = null;
}

?>
 <div style="margin:80px auto">

<main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i>Imagenes</h1>
          <p></p>


        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item">Imagenes</li>
          <li class="breadcrumb-item active"><a href="#">Lista</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
          <a style="margin-top:-40px; margin-bottom:20px;" class="btn btn-success" href="<?php echo $this->base_url?>AdminGaleria/add"><i class="fa fa-plus" aria-hidden="true"></i> Adicionar</a>

            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Descripcion</th>
					 <th>Acciones</th>
                  </tr>
                </thead>
                <tbody>
                 <?php $count = 0;?>
                         <?php if($list_img):?>   
                           <?php foreach($list_img as $listaImagem): ?> 
                            <?php $count++; $ccs_class=($count%2==0)?'even':'odd';?>  
						<tr class="<?php echo $ccs_class;?>">
                        <td><?php echo $listaImagem->getIdimagen() ?></td>
						<td>
						 <img src="<?php echo $this->base_url?>system/upload/<?php echo $listaImagem->getNombre()?>" width="100"/>
						</td>
                        <td><?php echo substr($listaImagem->getDescripcion(), 0,50)."...";?></td>      
						
                         <td class="center" style='font-size:10px; font-weight: bold;'>
                                        <a href="<?php echo $this->base_url?>AdminGaleria/editImagem/<?php echo $listaImagem->getIdimagen();?>"><i class="fa fa-edit fa-2x"></i></a>

                                        <a href='<?php echo $this->base_url?>AdminGaleria/delImagem/<?php echo $listaImagem->getIdimagen();?>'>&#128465;</a>
                                    </td>
                        </tr>
			<?php endforeach; ?>
                          <?php endif;?>   
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>

	   </div>
	                              