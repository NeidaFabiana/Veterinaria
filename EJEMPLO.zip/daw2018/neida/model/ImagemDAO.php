<?php


class ImagemDAO extends Model {

    private $listImagem;

    public function __construct() {
        parent::__construct();
        $this->listaImagem = [];
    }
	
	
    public function getListImagem() {
        $sql = "SELECT * FROM imagenes";
        $result = $this->ExecuteQuery($sql, []);

        foreach ($result as $linha) {
            $imagem = new Imagem($linha['nombre'], $linha['descripcion'], $linha['idImagenes']);

            $this->listImagem[] = $imagem;
        }

        return $this->listImagem;
    }

	public function getListUltimasImagem(){
        $sql = "SELECT * FROM imagenes order by idImagenes desc limit 3";
        $result = $this->ExecuteQuery($sql, []);

        foreach ($result as $linha) {
            $imagem = new Imagem($linha['nombre'], $linha['descripcion'], $linha['idImagenes']);

            $this->listImagem[] = $imagem;
        }

        return $this->listImagem;
    }
	

    public function getImagemById($img) {

            $sql = "SELECT * FROM imagenes  WHERE idImagenes = :idImagen;";
            $result = $this->ExecuteQuery($sql, [':idImagen' => $img]);

    
 if ($result) {
            $imgl = $result[0];
            return new Imagem($imgl['nombre'], $imgl['descripcion'],$imgl['idImagenes']);
        } else {
            return null;
        }
    }

	
   
	 public function insereImagem($img) {
        $sql = "INSERT INTO imagenes (nombre,descripcion) VALUES(:nombre,:descripcion)";
        $result = $this->ExecuteCommand($sql,
                [':nombre' => $img->getNombre(),
            ':descripcion' => $img->getDescripcion()]);
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

	 public function atualizarImagem($img) {
        $sql = 'UPDATE imagenes SET nombre = :nombre,'
                . ' descripcion=:descripcion  WHERE idImagenes =:idimagen';
        $param = [':nombre'=>$img->getNombre(),
            ':descripcion'=>$img->getDescripcion(),
            ':idimagen'=>$img->getIdimagen()];
        if($this->ExecuteCommand($sql, $param)){
            return true;
        }else{
            return false;
        }
    }
    
	
    public function removeImagem($id) {
        $sql = "DELETE FROM imagenes WHERE idImagenes = :idimag";
        if($this->ExecuteCommand($sql, [':idimag'=>$id])){
            return true;
        }else{
            return false;
        }
    }

    }
