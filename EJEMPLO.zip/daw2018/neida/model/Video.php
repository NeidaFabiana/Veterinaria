<?php


class Video {
    //put your code here
    
    
   
     private $titulo;
	 private $descripcion;
	 private $liink;
	 private $thumb;
     private $idvideos;
    
    public function __construct($titulo,$descripcion,$liink,$thumb,$idvideos=null) {
       
		$this->titulo = $titulo;
		$this->descripcion = $descripcion;
        $this->liink = $liink;
		$this->thumb = $thumb;
	    $this->idvideos = $idvideos;
    }

    function getTitulo() {
        return $this->titulo;
	 }
	
	 function getDescripcion() {
        return $this->descripcion;
   
    }
	function getLiink() {
        return $this->liink;
    }
	
	function getThumb() {
        return $this->thumb;
    }

	function getIdvideos() {
        return $this->idvideos;
    }

	 function setTitulo($titulo) {
        $this->titulo = $titulo;
    }
    function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }
	
    function setLink($liink) {
        $this->liink = $liink;
    }
	
	function setThumb($thumb) {
        $this->thumb = $thumb;
    }

	
    function setIdvideos($idvideos) {
        $this->idvideos = $idvideos;
    }
    
}
