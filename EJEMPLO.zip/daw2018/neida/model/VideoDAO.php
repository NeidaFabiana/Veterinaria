<?php

class VideoDAO extends Model {

    private $listVideo;

    public function __construct() {
        parent::__construct();
        $this->listVideo = [];
    }
	
	public function getNumVideo() {
        $sql = "SELECT COUNT(*) as num  FROM videos";
        $result = $this->ExecuteQuery($sql, []);
        return $result[0]['num'];
    }

    public function getListVideo() {
        $sql = "SELECT * FROM videos";
        $result = $this->ExecuteQuery($sql, []);

        foreach ($result as $linha) {
            $videos = new Video ($linha['titulo'], $linha['descripcion'],$linha['liink'],$linha['thumb'],$linha['idvideos']);

            $this->listVideo[] = $videos;
        }

        return $this->listVideo;
    }
	
	public function getListUltimasVideo(){
        $sql = "SELECT * FROM videos order by idvideos desc limit 3";
        $result = $this->ExecuteQuery($sql, []);

        foreach ($result as $linha) {
            $videos = new Video($linha['titulo'], $linha['descripcion'],$linha['liink'],$linha['thumb'],$linha['idvideos']);

            $this->listVideo[] = $videos;
        }

        return $this->listVideo;
    }
		
		
		 public function getVideoById($vide) {

            $sql = "SELECT * FROM videos  WHERE idvideos = :idvide;";
            $result = $this->ExecuteQuery($sql, [':idvide' => $vide]);

    
 if ($result) {
            $videl = $result[0];
            return new Video($videl['titulo'], $videl['descripcion'],$videl['liink'], $videl['thumb'],$videl['idvideos']);
        } else {
            return null;
        }
    }
		
		
        public function insereVideo($vid) {
            $sql = "INSERT INTO `videos`(`titulo`, `descripcion`, `liink`, `thumb`) VALUES(:titulo,:descripcion,:liink,:thumb)";
            if ($this->ExecuteCommand($sql, [':titulo' => $vid->getTitulo(), ':descripcion' => $vid->getDescripcion(), ':liink' => $vid->getLiink(), ':thumb' => $vid->getThumb()])) {
                return true;
            } else {
                return false;
            }
        }

		 public function atualizarVideo($video) {
	
        $sql = 'UPDATE videos SET titulo = :titulo,' . ' descripcion=:descripcion,'.' liink = :liink, '.' thumb = :thumb  WHERE idvideos =:idvideos';
        $param = [':titulo'=>$video->getTitulo(),
            ':descripcion'=>$video->getDescripcion(),
			':liink'=>$video->getLiink(),
			':thumb'=>$video->getThumb(),
            ':idvideos'=>$video->getIdvideos()];
        if($this->ExecuteCommand($sql, $param)){
            return true;
        }else{
            return false;
			}
		}
    
       
		 public function removeVideo($id) {
        $sql = "DELETE FROM videos WHERE idvideos = :idvideos";
        if($this->ExecuteCommand($sql, [':idvideos'=>$id])){
            return true;
        }else{
            return false;
        }
    }
}
