<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Imagen
 *
 * @author IFSul
 */
class Imagem {
    //put your code here
    
    
   
     private $nombre;
	 private $descripcion;
    private $idimagen;
    
    public function __construct($nombre,$descripcion,$idimagen=null) {
        $this->nombre = $nombre;
		$this->descripcion = $descripcion;
        $this->idimagen = $idimagen;
    }

    function getNombre() {
        return $this->nombre;
	 }
	
	 function getDescripcion() {
        return $this->descripcion;
   
    }

	
	function getIdimagen() {
        return $this->idimagen;
    }

	 function setNombre($nombre) {
        $this->nombre = $nombre;
    }
    function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

	
    function setIdimagen($idimagen) {
        $this->idimagen = $idimagen;
    }
    
}
