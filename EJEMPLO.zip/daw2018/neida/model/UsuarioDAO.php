<?php

class UsuarioDAO extends Model {

    private $listUsuario;

    public function __construct() {
        parent::__construct();
        $this->listaUsuario = [];
    }

    public function getListUsuario() {
        $sql = "SELECT * FROM usuario";
        $result = $this->ExecuteQuery($sql, []);

        foreach ($result as $linha) {
            $usuario = new Usuario( $linha['id_user'],$linha['nome'], $linha['login'], $linha['senha'], $linha['email']);

            $this->listUsuario[] = $usuario;
        }

        return $this->listUsuario;
    }

        public function insertUsuario($user) {
            $sql = "INSERT INTO `usuario`(`nome`, `login`, `senha`, `email`) VALUES(:nome,:login,:senha,:email)";
            if ($this->ExecuteCommand($sql, [':nome' => $user->getNome(), ':login' => $user->getLogin(), ':senha' => $user->getSenha(), ':email' => $user->getEmail()])) {
                return true;
            } else {
                return false;
            }
        }
        public function updateUsuario($usuario) {
            $sql = "UPDATE usuario SET nome = :nome , login = :login, senha = :senha, email = :email  WHERE  id_user = :id_user";
            $param=[':nome'=>$usuario->getNome(),':login'=>$usuario->getLogin(), ':senha'=>$usuario->getSenha(),':email'=>$usuario->getEmail(),':id_user'=>$usuario->getId_user()];
            if($this->ExecuteCommand($sql, $param)){
                return true;
            }else{
                return false;
            }
        }


        public function getUsuarioById($id) {
          $sql = "SELECT * FROM usuario  WHERE id_user = :id_user";
            $result = $this->ExecuteQuery($sql, [':id_user' => $id]);

            if ($result) {
                $usuario = $result[0];
                return new Usuario($usuario['id_user'], $usuario['nome'], $usuario['login'], $usuario['senha'], $usuario['email']);
            } else {
                return null;
            }
        }

        public function removeUsuario($id){
            $sql = "DELETE FROM usuario WHERE id_user = :id_user";
            if($this->ExecuteCommand($sql, [':id_user'=>$id])){
                return true;
            }else{
                return false;
            }
        }



}
