<?php

class Usuario {
    private $login;
    private $senha;
    private $email;
    private $nome;
    private $id_user;

    public function __construct($id_user=null,$nome,$login, $senha,$email) {
        $this->login = $login;
        $this->senha = $senha;
        $this->nome = $nome;
        $this->email = $email;
        $this->id_user = $id_user;
    }


    function getLogin() {
        return $this->login;
    }
    function getEmail() {
        return $this->email;
    }
    function getSenha() {
        return $this->senha;
    }
    function getNome() {
        return $this->nome;
    }

    function getId_user() {
        return $this->id_user;
    }


    function setLogin($login) {
        $this->login = $login;
    }
    function setEmail($email) {
        $this->email = $email;
    }
    function setSenha($senha) {
        $this->senha = $senha;
    }
    function setNome($nome) {
        $this->nome = $nome;
    }

    function setId_user($id_user) {
        $this->id_user = $id_user;
    }

}
