<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Noticia
 *
 * @author IFSul
 */
class Noticia {
    //put your code here
    
    
   
     private $title;
	 private $descripcion;
    private $idnoticia;
	private $listimagens;
    
    public function __construct($title,$descripcion,$listimagens=null,$idnoticia=null) {
        $this->title = $title;
		$this->descripcion = $descripcion;
        $this->idnoticia = $idnoticia;
		$this->listimagens = $listimagens;
    }

    function getTitle() {
        return $this->title;
	 }
	
	 function getDescripcion() {
        return $this->descripcion;
   
    }
	function getIdnoticia() {
        return $this->idnoticia;
    }
	function getListimagens() {
        return $this->listimagens;
    }

    function setListimagens($listimagens) {
        $this->listimagens = $listimagens;
    }

	 function setTitle($title) {
        $this->title = $title;
    }
    function setDescripcion($descripcion) {
        $this->descripcion = $descripcion;
    }

    function setIdnoticia($idnoticia) {
        $this->idnoticia = $idnoticia;
    }
    
}
