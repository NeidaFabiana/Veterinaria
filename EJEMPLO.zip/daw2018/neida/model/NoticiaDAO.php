<?php

class NoticiaDAO  extends Model{

    private $listNoticias;

  public function __construct() {
        parent::__construct();
        $this->listaNoticias = [];
    }
	

	  public function getListNoticias() {
        $sql = "SELECT * FROM news";
        $result = $this->ExecuteQuery($sql, []);

        foreach ($result as $linha) {
            $noticia = new Noticia($linha['title'], $linha['descripcion'],$linha['listimagens'], $linha['idNews']);

            $this->listNoticias[] = $noticia;
        }

        return $this->listNoticias;
    }
	
	
 public function getListUltimasNoticias(){
        $sql = "SELECT * FROM news order by idNews desc limit 3";
        $result = $this->ExecuteQuery($sql, []);

        foreach ($result as $linha) {
            $noticia = new Noticia($linha['title'], $linha['descripcion'],$linha['listimagens'], $linha['idNews']);

            $this->listNoticias[] = $noticia;
        }

        return $this->listNoticias;
    }
	
	
	  public function getListNoticiasImagens() {
        $sql = "SELECT * FROM news";
        $result = $this->ExecuteQuery($sql, []);
        foreach ($result as $linha) {

            $listimagens = $this->getImagenFromNoticia($linha['idNews']);

            $noticia = new Noticia($linha['title'], $linha['descripcion'], $listimagens, $linha['idNews']);

            $this->listNoticias[] = $noticia;
        }
        return $this->listNoticias;
    }
	
	 public function getListUltimasNoticiasImagens() {
        $sql = "SELECT * FROM news order by idNews desc limit 3";
        $result = $this->ExecuteQuery($sql, []);
        foreach ($result as $linha) {

            $listimagens = $this->getImagenFromNoticia($linha['idNews']);

            $noticia = new Noticia($linha['title'], $linha['descripcion'], $listimagens, $linha['idNews']);

            $this->listNoticias[] = $noticia;
        }
        return $this->listNoticias;
    }

    public function getNoticiaById($id) {
        $sql = "SELECT * FROM news WHERE idNews = :idNews";
        $result = $this->ExecuteQuery($sql, [':idNews' => $id]);
       // echo "<pre>";
       // print_r($result);
       //  echo "</pre>";
		// die;
        if ($result) {
            $listimagens = $this->getImagenFromNoticia($id);
            $news = $result[0];
            return new Noticia($news['title'], $news['descripcion'], $listimagens, $news['idNews']);
        } else {
            return null;
        }
    }

    public function getImagenFromNoticia($id) {
        $sql =  "SELECT i.* FROM news_has_imagenes AS ni "
                . "INNER JOIN  imagenes as i "
                . "ON i.idImagenes = ni.Imagenes_idImagenes WHERE News_idNews = :News_idNews;";
        $result = $this->ExecuteQuery($sql, [':News_idNews' => $id]);
        $listaimagen=[];
        if ($result) {
             foreach ($result as $linha) {
                 $listaimagen[] = new Imagem(

                         $linha['nombre'],
                         $linha['descripcion'],
                         $linha['idImagenes']);
             }
            }
        return $listaimagen;
    }
	 public function insereNoticia($news) {
        $sql = "INSERT INTO news(title,descripcion) VALUES(:title,:descripcion)";
        $result = $this->ExecuteCommand($sql,
                [':title' => $news->getTitle(),
            ':descripcion' => $news->getDescripcion()]);
        if ($result) {
            return true;
        } else {
            return false;
        }
    }
	
	
	
	    public function removerNoticia($id) {
			
		if($this->ExecuteQuery("SELECT * FROM news_has_imagenes WHERE News_idNews  = :News_idNews", [':News_idNews' => $id])){
			$sql = "DELETE FROM news_has_imagenes WHERE News_idNews = :idn";
			if($this->ExecuteCommand($sql, [':idn'=>$id])){
				$sql = "DELETE FROM news WHERE idNews = :idnoticia";
				if($this->ExecuteCommand($sql, [':idnoticia'=>$id])){
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}	
		}else{
			$sql = "DELETE FROM news WHERE idNews = :idnoticia";
			if($this->ExecuteCommand($sql, [':idnoticia'=>$id])){
				return true;
			}else{
				return false;
			}
		}
		
    }
    

	 public function atualizarNoticia($noticia) {
        $sql = 'UPDATE news SET title = :title,'
                . ' descripcion=:descripcion WHERE idNews =:idnoticia';
        $param = [':title'=>$noticia->getTitle(),
            ':descripcion'=>$noticia->getDescripcion(),
            ':idnoticia'=>$noticia->getIdnoticia()];
        if($this->ExecuteCommand($sql, $param)){
            return true;
        }else{
            return false;
        }
    }
	
}
