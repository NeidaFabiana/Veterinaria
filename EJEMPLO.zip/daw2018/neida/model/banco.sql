-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 19-Dez-2018 às 18:49
-- Versão do servidor: 10.1.24-MariaDB
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `imagenes`
--

CREATE TABLE `imagenes` (
  `idImagenes` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `imagenes`
--

INSERT INTO `imagenes` (`idImagenes`, `nombre`, `descripcion`) VALUES
(1, 'uno.jpg', 'Primer noticia.'),
(2, 'dos.jpg', 'Segunda noticia'),
(3, 'tres.jpg', 'Tercer noticia'),
(4, 'cuatro.jpg', 'Cuarta noticia'),
(5, 'cinco.jpg', 'Quita noticia');

-- --------------------------------------------------------

--
-- Estrutura da tabela `news`
--

CREATE TABLE `news` (
  `idNews` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `listimagens` varchar(45) DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `news`
--

INSERT INTO `news` (`idNews`, `title`, `listimagens`, `descripcion`) VALUES
(1, 'La primera dama de Brasil se lanza a un lago.', NULL, 'La acción protagonizada por Marcela Temer ha generado una cascada de bromas en las redes sociales.La primera dama de Brasil, Marcela Temer, se lanzó vestida al lago del palacio presidencial para salvar a su perro, protagonizando un rescate que ha generado una cascada de bromas en las redes sociales.'),
(2, 'Un perro anciano ayuda a salvar a una niña', NULL, 'Aurora, una niña australiana de tres años, desapareció el pasado viernes sobre las tres de la tarde. La pequeña se alejó de su casa y se adentró en un bosque en Queensland, en el noreste de Australia. Max, el perro de la familia, la siguió y permaneció con ella hasta que la encontraron, 16 horas más'),
(3, 'Escalada de multas a los propietarios de perro', NULL, '2.463. Es el número total de sanciones que la Guardia Urbana interpuso durante el 2017 en el marco de la ordenanza de tenencia responsable de animales de la ciudad de Barcelona. Las infracciones en este ámbito fueron 215 más el año pasado que en el 2016, que se registraron 2.248 denuncias, lo que su'),
(4, 'Sobre dar besos a nuestros perros y gatos', NULL, 'Este viernes 13 de abril fue el Día Internacional del Beso, pero me pilló con el pie cambiado. Os confieso que me di cuenta tarde de que quería hablar del tema, de los besos que damos a nuestros animales y que ellos nos dan.\r\n				No sé vosotros. Yo vivo con normalidad las demostraciones de afecto en'),
(7, 'Jubilan a 61 perros en la policía de Ecuador', NULL, 'La ceremonia estaba finamente organizada: había alfombra roja, himno nacional, uniformes, bendiciones y una mezcla de tristeza y alegría que inundó a los policías que debían entregar a sus fieles compañeros de trabajo a sus nuevos dueños.\r\n				Un total de 61 canes, que prestaron su servicio a la Pol');

-- --------------------------------------------------------

--
-- Estrutura da tabela `news_has_imagenes`
--

CREATE TABLE `news_has_imagenes` (
  `News_idNews` bigint(20) UNSIGNED NOT NULL,
  `Imagenes_idImagenes` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `news_has_imagenes`
--

INSERT INTO `news_has_imagenes` (`News_idNews`, `Imagenes_idImagenes`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(7, 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `news_has_videos`
--

CREATE TABLE `news_has_videos` (
  `News_idNews` bigint(20) UNSIGNED NOT NULL,
  `Videos_idVideos` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id_user` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(200) NOT NULL,
  `login` varchar(200) NOT NULL,
  `senha` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `foto` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id_user`, `nome`, `login`, `senha`, `email`, `foto`) VALUES
(2, 'yy', 'y6y', '6y6', '6y6y', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `videos`
--

CREATE TABLE `videos` (
  `idvideos` bigint(20) UNSIGNED NOT NULL,
  `titulo` varchar(30) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `liink` varchar(100) DEFAULT NULL,
  `thumb` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `videos`
--

INSERT INTO `videos` (`idvideos`, `titulo`, `descripcion`, `liink`, `thumb`) VALUES
(1, 'Como adiestrar', 'pasos', 'z1cz4c36w_o', 'z1cz4c36w_o'),
(2, 'Cinco trucos', 'algunos trucos', 'p9emMdjoQf4', 'p9emMdjoQf4'),
(3, 'Hacer necesidades', 'ayudar ', 'Sdape1sHbWA', 'Sdape1sHbWA');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `imagenes`
--
ALTER TABLE `imagenes`
  ADD PRIMARY KEY (`idImagenes`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`idNews`);

--
-- Indexes for table `news_has_imagenes`
--
ALTER TABLE `news_has_imagenes`
  ADD PRIMARY KEY (`News_idNews`,`Imagenes_idImagenes`),
  ADD KEY `fk_News_has_Imagenes_Imagenes1_idx` (`Imagenes_idImagenes`),
  ADD KEY `fk_News_has_Imagenes_News1_idx` (`News_idNews`);

--
-- Indexes for table `news_has_videos`
--
ALTER TABLE `news_has_videos`
  ADD PRIMARY KEY (`News_idNews`,`Videos_idVideos`),
  ADD KEY `fk_News_has_Videos_Videos1_idx` (`Videos_idVideos`),
  ADD KEY `fk_News_has_Videos_News1_idx` (`News_idNews`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`idvideos`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `imagenes`
--
ALTER TABLE `imagenes`
  MODIFY `idImagenes` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `idNews` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_user` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `idvideos` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `news_has_imagenes`
--
ALTER TABLE `news_has_imagenes`
  ADD CONSTRAINT `fk_News_has_Imagenes_Imagenes1` FOREIGN KEY (`Imagenes_idImagenes`) REFERENCES `imagenes` (`idImagenes`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_News_has_Imagenes_News1` FOREIGN KEY (`News_idNews`) REFERENCES `news` (`idNews`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `news_has_videos`
--
ALTER TABLE `news_has_videos`
  ADD CONSTRAINT `fk_News_has_Videos_News1` FOREIGN KEY (`News_idNews`) REFERENCES `news` (`idNews`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_News_has_Videos_Videos1` FOREIGN KEY (`Videos_idVideos`) REFERENCES `videos` (`idvideos`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
