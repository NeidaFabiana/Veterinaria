<?php
class Imagenes extends Controller{

    //private $texto;

    public function __construct() {
        parent::__construct();
      $this->model=new ImagemDAO();     
    }

    public function index(){
        $data['listImagem']=$this->model->getListImagem();
        $this->view->load("header");
        $this->view->load("nav_1");
        $this->view->load("imagens",$data);
        $this->view->load("footer");
    }

    
}
