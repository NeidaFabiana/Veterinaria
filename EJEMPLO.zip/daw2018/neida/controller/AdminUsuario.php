<?php


class AdminUsuario extends Admin {


    function __construct() {
        parent::__construct();
        $this->model = new UsuarioDAO();
    }

    public function index() {
      $data['listUsuario'] = $this->model->getListUsuario();
        $this->view->load('header');
        $this->view->load('nav');
        $this->view->load('user_list',$data);
        $this->view->load('footer');
    }

    public function add() {
        $data['msg']="";
        if (filter_input(INPUT_POST, 'add')) {
          $nome = filter_input(INPUT_POST, 'nome',FILTER_SANITIZE_STRING);
          $login = filter_input(INPUT_POST, 'login',FILTER_SANITIZE_STRING);
          $senha = filter_input(INPUT_POST, 'senha',FILTER_SANITIZE_STRING);
          $email = filter_input(INPUT_POST, 'email',FILTER_SANITIZE_STRING);

            if($nome && $login && $senha && $email) {
                if($this->model->insertUsuario(new Usuario(null, $nome, $login, $senha, $email))){
                    $this->view->location('AdminUsuario');
                }else{
                    $data['msg']= "Erro ao cadastrar!!";
                }
            }else{
                $data['msg']= "Preencha todos os campos!";
            }
        }
        $this->view->load('header');
        $this->view->load('nav');
        $this->view->load('user_add',$data);
        $this->view->load('footer');
    }
    public function editUsuario($id) {
      $data['usuario'] = $this->model->getUsuarioById($id);
      $data['msg'] = "";

        if (filter_input(INPUT_POST,'upd')) {

          $nome = filter_input(INPUT_POST, 'nome',FILTER_SANITIZE_STRING);
          $login = filter_input(INPUT_POST, 'login',FILTER_SANITIZE_STRING);
          $senha = filter_input(INPUT_POST, 'senha',FILTER_SANITIZE_STRING);
          $email = filter_input(INPUT_POST, 'email',FILTER_SANITIZE_STRING);


          if($nome && $login && $senha && $email ) {
                //atualizar no banco de dados a notícia
                $usuario = new Usuario($id,$nome,$login,$senha,$email);
                if ($this->model->updateUsuario($usuario)) {
                  $this->index();
                  return true;
                } else {
                  $data['msg'] = 'Erro ao atualizar Usuario!';

                }
                } else {
                $data['msg'] = 'Preencha todos os campos!';
                }
        }
                
                $this->view->load('header');
                $this->view->load('nav');
                $this->view->load('user_upd', $data);
                $this->view->load('footer');
                }


                public function removeUsuario($id) {
                    $data['usuario'] = $this->model->getUsuarioById($id);
                    $data['msg']="";

                      if (filter_input(INPUT_POST, 'del')) {
                        $this->model->removeUsuario($id);
                          $this->index();
                      } else {
                          $this->view->load('header');
                          $this->view->load('nav');
                          $this->view->load('user_del', $data);
                          $this->view->load('footer');
                      }
                  }

				  

}
