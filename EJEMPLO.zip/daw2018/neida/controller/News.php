<?php

class News extends Controller {

    //put your code here

    public function __construct() {
        parent::__construct();
		  $this->model=new NoticiaDAO();
    }

    public function index() {
 $data['listNews'] = $this->model->getListNoticiasImagens();

        $this->view->load("header");
        $this->view->load("nav_1");
        $this->view->load("news",$data);
        $this->view->load("footer");
    }

		 public function viewNews($idnews) {
        //Método buscar no banco pelo ID 
        $data['noticia'] = $this->model->getNoticiaById($idnews);
		
        //Mostrar a notícia na página 
       if ($data['noticia']) {

            $this->view->load("header");
            $this->view->load("nav_1");
            $this->view->load("view_news",$data);
            $this->view->load("footer");
            
        } else {
            echo "Notícia não foi encontrada";
        }
    }

}
