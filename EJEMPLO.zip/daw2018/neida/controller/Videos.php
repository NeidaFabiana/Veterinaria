<?php
class Videos extends Controller{


    public function __construct() {
        parent::__construct();
		$this->model = new VideoDAO();    
    }

    public function index(){
       $data['listVideo'] = $this->model->getListVideo();
	   
        $this->view->load('header');
        $this->view->load('nav_1');
        $this->view->load('videos',$data);
        $this->view->load('footer');
    }

   

}
