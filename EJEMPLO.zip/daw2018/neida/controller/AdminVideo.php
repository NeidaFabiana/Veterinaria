<?php

class AdminVideo extends Admin {


    function __construct() {
        parent::__construct();
        $this->model = new VideoDAO();
    }

    public function index() {
        $data['listVideo'] = $this->model->getListVideo();
        $this->view->load("header");
        $this->view->load("nav");
        $this->view->load("video_list",$data);
        $this->view->load("footer");
    }

    public function add() {
        $data['msg']="";
        if (filter_input(INPUT_POST, 'add')) {
          $titulo = filter_input(INPUT_POST, 'titulo',FILTER_SANITIZE_STRING);
          $descripcion = filter_input(INPUT_POST, 'descripcion',FILTER_SANITIZE_STRING);
		  $liink = filter_input(INPUT_POST, 'liink',FILTER_SANITIZE_STRING);
		  $thumb = filter_input(INPUT_POST, 'thumb',FILTER_SANITIZE_STRING);

            if($titulo && $descripcion && $liink && $thumb) {
                if($this->model->insereVideo(new Video($titulo,$descripcion,$liink,$thumb))){
                    $this->view->location('AdminVideo');
                }else{
                    $data['msg']= "Erro ao cadastrar!!";
                }
            }else{
                $data['msg']= "Preencha todos os campos!";
            }
        }
        $this->view->load('header');
        $this->view->load('nav');
        $this->view->load('video_add',$data);
        $this->view->load('footer');
    }

	

	public function editVideo($id) {
        $data['vide'] = $this->model->getVideoById($id);
        $data['msg'] = "";

        if (filter_input(INPUT_POST, 'edit')) {
            //ler formulário e atualizar o banco

            $titulo = filter_input(INPUT_POST, 'titulo', FILTER_SANITIZE_STRING);
            $descripcion = filter_input(INPUT_POST, 'descripcion', FILTER_SANITIZE_STRING);
            $liink = filter_input(INPUT_POST, 'liink', FILTER_SANITIZE_STRING);
			$thumb = filter_input(INPUT_POST, 'thumb', FILTER_SANITIZE_STRING);
			$idvideos = filter_input(INPUT_POST, 'idvideos', FILTER_SANITIZE_STRING);

			
			
			
            if ($titulo && $descripcion && $liink && $thumb && $idvideos) {
                //atualizar no banco de dados a notícia
                $video = new Video($titulo, $descripcion, $liink, $thumb, $idvideos);
                if ($this->model->atualizarVideo($video)) {
                    $this->view->location("AdminVideo");
                    return true;
                } else {
                    $data['msg'] = "Erro ao atualizar video!!";
                }
            } else {
                $data['msg'] = "Informe Todos os campos!!";
            }
        } else if (filter_input(INPUT_POST, 'exit')) {
            $this->view->location("AdminVideo");
//            $this->index();
            return TRUE;
        }

        $this->view->load('header');
        $this->view->load('nav');
        $this->view->load('video_upd', $data);
        $this->view->load('footer');
    }
	
	 public function delVideo($id) {
        $data['msg'] = '';
//        echo "Deletar Notícia: $id";
        $data['vide'] = $this->model->getVideoById($id);
        $this->view->load('header');
        $this->view->load('nav');
        $this->view->load('video_del', $data);
        $this->view->load('footer');
    }

    public function removeVideo() {
        $data['msg'] = '';
        if (filter_input(INPUT_POST, 'del')) {
            $idvideos = filter_input(INPUT_POST,'idvideos',FILTER_SANITIZE_STRING);
            if($this->model->removeVideo($idvideos)){
                $data['msg'] ='Video eliminado con exito!';
            }else{
                $data['msg'] ='Error al eliminar video!';            
            }           
        } elseif (filter_input(INPUT_POST, 'exit')) {
            $this->view->location('AdminVideo/');
        } else {
            $data['msg'] = 'Error en el formulário!';
        }
        $this->view->load('header');
        $this->view->load('nav');
        $this->view->load('video_remove', $data);
        $this->view->load('footer');
        
    }
	
}